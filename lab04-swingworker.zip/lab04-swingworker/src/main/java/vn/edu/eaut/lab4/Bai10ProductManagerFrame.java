package vn.edu.eaut.lab4;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Vector;

public class Bai10ProductManagerFrame extends JFrame {
    private JTextField txtMaSP, txtTenSP, txtDonGia, txtSearch;
    private JButton btnAdd, btnEdit, btnDelete, btnSaveFile, btnReadFile;
    private JTable table;
    private DefaultTableModel tableModel;
    private TableRowSorter<DefaultTableModel> sorter;

    public Bai10ProductManagerFrame() {
        setTitle("Bài 10 - Quản lý sản phẩm (Mini Project)");
        setSize(750, 550);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        txtMaSP = new JTextField(8);
        txtTenSP = new JTextField(12);
        txtDonGia = new JTextField(10);

        JPanel inputPanel = new JPanel();
        inputPanel.add(new JLabel("Mã SP:")); inputPanel.add(txtMaSP);
        inputPanel.add(new JLabel("Tên SP:")); inputPanel.add(txtTenSP);
        inputPanel.add(new JLabel("Đơn giá:")); inputPanel.add(txtDonGia);

        btnAdd = new JButton("Thêm");
        btnEdit = new JButton("Sửa");
        btnDelete = new JButton("Xóa");
        btnSaveFile = new JButton("Lưu CSV");
        btnReadFile = new JButton("Đọc CSV");

        JPanel actionPanel = new JPanel();
        actionPanel.add(btnAdd); actionPanel.add(btnEdit); actionPanel.add(btnDelete);
        actionPanel.add(btnSaveFile); actionPanel.add(btnReadFile);

        txtSearch = new JTextField(20);
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.add(new JLabel(" 🔍 Tìm kiếm sản phẩm: "));
        searchPanel.add(txtSearch);

        JPanel topContainer = new JPanel();
        topContainer.setLayout(new BoxLayout(topContainer, BoxLayout.Y_AXIS));
        topContainer.add(inputPanel);
        topContainer.add(actionPanel);
        topContainer.add(searchPanel);

        tableModel = new DefaultTableModel(new String[]{"Mã SP", "Tên SP", "Đơn Giá"}, 0);
        table = new JTable(tableModel);

        sorter = new TableRowSorter<>(tableModel);
        table.setRowSorter(sorter);

        setLayout(new BorderLayout(10, 10));
        add(topContainer, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);

        setupSearchFilter();

        btnAdd.addActionListener(e -> addProduct());
        btnEdit.addActionListener(e -> editProduct());
        btnDelete.addActionListener(e -> deleteProduct());
        btnSaveFile.addActionListener(e -> saveCsvAsync());
        btnReadFile.addActionListener(e -> readCsvAsync());

        table.getSelectionModel().addListSelectionListener(e -> fillFormFromTable());
    }

    private void setupSearchFilter() {
        txtSearch.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { filter(); }
            @Override
            public void removeUpdate(DocumentEvent e) { filter(); }
            @Override
            public void changedUpdate(DocumentEvent e) { filter(); }

            private void filter() {
                String text = txtSearch.getText().trim();
                if (text.isEmpty()) {
                    sorter.setRowFilter(null);
                } else {
                    sorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                }
            }
        });
    }

    private void addProduct() {
        if (!validateInput()) return;
        tableModel.addRow(new Object[]{txtMaSP.getText().trim(), txtTenSP.getText().trim(), txtDonGia.getText().trim()});
        clearInputs();
    }

    private void editProduct() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Chọn dòng cần sửa");
            return;
        }
        int modelRow = table.convertRowIndexToModel(selectedRow);

        if (!validateInput()) return;
        tableModel.setValueAt(txtMaSP.getText().trim(), modelRow, 0);
        tableModel.setValueAt(txtTenSP.getText().trim(), modelRow, 1);
        tableModel.setValueAt(txtDonGia.getText().trim(), modelRow, 2);
        clearInputs();
    }

    private void deleteProduct() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            int modelRow = table.convertRowIndexToModel(selectedRow);
            tableModel.removeRow(modelRow);
            clearInputs();
        } else {
            JOptionPane.showMessageDialog(this, "Chọn dòng cần xóa");
        }
    }

    private void fillFormFromTable() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            int modelRow = table.convertRowIndexToModel(selectedRow);
            txtMaSP.setText(tableModel.getValueAt(modelRow, 0).toString());
            txtTenSP.setText(tableModel.getValueAt(modelRow, 1).toString());
            txtDonGia.setText(tableModel.getValueAt(modelRow, 2).toString());
        }
    }

    private boolean validateInput() {
        if (txtMaSP.getText().isBlank() || txtTenSP.getText().isBlank() || txtDonGia.getText().isBlank()) {
            JOptionPane.showMessageDialog(this, "Điền đầy đủ thông tin!");
            return false;
        }
        try {
            Double.parseDouble(txtDonGia.getText().trim());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Đơn giá phải là số!");
            return false;
        }
        return true;
    }

    private void clearInputs() {
        txtMaSP.setText(""); txtTenSP.setText(""); txtDonGia.setText("");
        table.clearSelection();
    }

    private void saveCsvAsync() {
        JFileChooser chooser = new JFileChooser();
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        File file = chooser.getSelectedFile();

        new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() throws Exception {
                try (BufferedWriter writer = Files.newBufferedWriter(file.toPath(), StandardCharsets.UTF_8)) {
                    writer.write("MaSP,TenSP,DonGia\n");
                    for (int i = 0; i < tableModel.getRowCount(); i++) {
                        String line = String.format("%s,%s,%s\n",
                                tableModel.getValueAt(i, 0),
                                tableModel.getValueAt(i, 1),
                                tableModel.getValueAt(i, 2));
                        writer.write(line);
                    }
                }
                return null;
            }

            @Override
            protected void done() {
                JOptionPane.showMessageDialog(Bai10ProductManagerFrame.this, "Lưu dữ liệu ra CSV thành công!");
            }
        }.execute();
    }

    private void readCsvAsync() {
        JFileChooser chooser = new JFileChooser();
        if (chooser.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) return;
        File file = chooser.getSelectedFile();

        tableModel.setRowCount(0);
        new SwingWorker<Void, Vector<Object>>() {
            @Override
            protected Void doInBackground() throws Exception {
                try (BufferedReader reader = Files.newBufferedReader(file.toPath(), StandardCharsets.UTF_8)) {
                    String line;
                    boolean isHeader = true;
                    while ((line = reader.readLine()) != null) {
                        if (isHeader) { isHeader = false; continue; }
                        String[] parts = line.split(",");
                        if (parts.length >= 3) {
                            Vector<Object> row = new Vector<>();
                            row.add(parts[0].trim());
                            row.add(parts[1].trim());
                            row.add(parts[2].trim());
                            publish(row);
                        }
                    }
                }
                return null;
            }

            @Override
            protected void process(java.util.List<Vector<Object>> chunks) {
                for (Vector<Object> row : chunks) {
                    tableModel.addRow(row);
                }
            }

            @Override
            protected void done() {
                JOptionPane.showMessageDialog(Bai10ProductManagerFrame.this, "Nạp dữ liệu từ CSV thành công!");
            }
        }.execute();
    }
}