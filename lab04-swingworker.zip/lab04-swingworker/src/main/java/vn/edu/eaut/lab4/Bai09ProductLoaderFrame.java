package vn.edu.eaut.lab4;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class Bai09ProductLoaderFrame extends JFrame {
    private JButton btnLoad;
    private JProgressBar progressBar;
    private JTable table;
    private DefaultTableModel tableModel;
    private JLabel lblStatus;

    public Bai09ProductLoaderFrame() {
        setTitle("Bài 9 - Mô phỏng tải sản phẩm");
        setSize(550, 350);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        btnLoad = new JButton("Tải sản phẩm");
        progressBar = new JProgressBar(0, 100);
        progressBar.setStringPainted(true);
        lblStatus = new JLabel("Chưa tải", SwingConstants.CENTER);

        tableModel = new DefaultTableModel(new String[]{"Mã SP", "Tên SP", "Đơn Giá"}, 0);
        table = new JTable(tableModel);

        JPanel topPanel = new JPanel();
        topPanel.add(btnLoad);

        JPanel bottomPanel = new JPanel(new GridLayout(2, 1));
        bottomPanel.add(progressBar);
        bottomPanel.add(lblStatus);

        setLayout(new BorderLayout(10, 10));
        add(topPanel, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        btnLoad.addActionListener(e -> loadProducts());
    }

    private void loadProducts() {
        btnLoad.setEnabled(false);
        tableModel.setRowCount(0);
        lblStatus.setText("Đang kết nối dữ liệu...");

        SwingWorker<Void, Object[]> worker = new SwingWorker<>() {
            @Override
            protected Void doInBackground() throws Exception {
                Object[][] dummyData = {
                        {"SP01", "Bàn phím Mechanical", 250000.0},
                        {"SP02", "Chuột Wireless", 150000.0},
                        {"SP03", "Màn hình 24 inch", 2500000.0},
                        {"SP04", "Tai nghe Gaming", 450000.0},
                        {"SP05", "Lót chuột RGB", 80000.0}
                };

                for (int i = 0; i < dummyData.length; i++) {
                    Thread.sleep(600);
                    publish(dummyData[i]);
                    setProgress((i + 1) * 100 / dummyData.length);
                }
                return null;
            }

            @Override
            protected void process(List<Object[]> chunks) {
                for (Object[] row : chunks) {
                    tableModel.addRow(row);
                }
            }

            @Override
            protected void done() {
                lblStatus.setText("Tải danh sách sản phẩm hoàn tất!");
                btnLoad.setEnabled(true);
            }
        };

        worker.addPropertyChangeListener(evt -> {
            if ("progress".equals(evt.getPropertyName())) {
                progressBar.setValue((int) evt.getNewValue());
            }
        });

        worker.execute();
    }
}