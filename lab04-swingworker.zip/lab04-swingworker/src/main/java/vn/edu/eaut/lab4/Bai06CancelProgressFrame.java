package vn.edu.eaut.lab4;

import javax.swing.*;
import java.awt.*;

public class Bai06CancelProgressFrame extends JFrame {
    private JButton btnStart, btnCancel;
    private JProgressBar progressBar;
    private JLabel lblStatus;
    private SwingWorker<Void, Integer> worker;

    public Bai06CancelProgressFrame() {
        setTitle("Bài 6 - Hủy tác vụ SwingWorker");
        setSize(450, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        btnStart = new JButton("Bắt đầu");
        btnCancel = new JButton("Hủy");
        btnCancel.setEnabled(false);

        progressBar = new JProgressBar(0, 100);
        progressBar.setStringPainted(true);
        lblStatus = new JLabel("Trạng thái: Chưa chạy", SwingConstants.CENTER);

        JPanel btnPanel = new JPanel();
        btnPanel.add(btnStart);
        btnPanel.add(btnCancel);

        JPanel centerPanel = new JPanel(new GridLayout(2, 1, 5, 5));
        centerPanel.add(progressBar);
        centerPanel.add(lblStatus);

        setLayout(new BorderLayout(10, 10));
        add(btnPanel, BorderLayout.NORTH);
        add(centerPanel, BorderLayout.CENTER);

        btnStart.addActionListener(e -> startTask());
        btnCancel.addActionListener(e -> cancelTask());
    }

    private void startTask() {
        btnStart.setEnabled(false);
        btnCancel.setEnabled(true);
        progressBar.setValue(0);
        lblStatus.setText("Trạng thái: Đang xử lý...");

        worker = new SwingWorker<>() {
            @Override
            protected Void doInBackground() throws Exception {
                for (int i = 0; i <= 100; i += 5) {
                    if (isCancelled()) break;
                    setProgress(i);
                    Thread.sleep(300);
                }
                return null;
            }

            @Override
            protected void done() {
                btnStart.setEnabled(true);
                btnCancel.setEnabled(false);
                if (isCancelled()) {
                    lblStatus.setText("Trạng thái: Đã hủy tác vụ");
                } else {
                    progressBar.setValue(100);
                    lblStatus.setText("Trạng thái: Hoàn thành!");
                }
            }
        };

        worker.addPropertyChangeListener(evt -> {
            if ("progress".equals(evt.getPropertyName())) {
                progressBar.setValue((int) evt.getNewValue());
            }
        });

        worker.execute();
    }

    private void cancelTask() {
        if (worker != null && !worker.isDone()) {
            worker.cancel(true);
        }
    }
}