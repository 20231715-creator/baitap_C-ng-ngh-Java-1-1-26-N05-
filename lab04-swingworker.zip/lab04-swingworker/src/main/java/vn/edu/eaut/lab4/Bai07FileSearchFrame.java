package vn.edu.eaut.lab4;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.List;

public class Bai07FileSearchFrame extends JFrame {
    private JTextField txtKeyword;
    private JButton btnChoose, btnSearch;
    private JTextArea txtResult;
    private JLabel lblStatus;
    private File selectedFile;

    public Bai07FileSearchFrame() {
        setTitle("Bài 7 - Tìm kiếm từ khóa trong file");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        btnChoose = new JButton("Chọn File");
        txtKeyword = new JTextField(15);
        btnSearch = new JButton("Tìm kiếm");
        txtResult = new JTextArea();
        txtResult.setEditable(false);
        lblStatus = new JLabel("Chưa chọn file", SwingConstants.CENTER);

        JPanel topPanel = new JPanel();
        topPanel.add(btnChoose);
        topPanel.add(new JLabel("Từ khóa:"));
        topPanel.add(txtKeyword);
        topPanel.add(btnSearch);

        setLayout(new BorderLayout(10, 10));
        add(topPanel, BorderLayout.NORTH);
        add(new JScrollPane(txtResult), BorderLayout.CENTER);
        add(lblStatus, BorderLayout.SOUTH);

        btnChoose.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser();
            if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
                selectedFile = chooser.getSelectedFile();
                lblStatus.setText("Đã chọn: " + selectedFile.getName());
            }
        });

        btnSearch.addActionListener(e -> searchKeyword());
    }

    private void searchKeyword() {
        if (selectedFile == null) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn file");
            return;
        }
        String keyword = txtKeyword.getText().trim().toLowerCase();
        if (keyword.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập từ khóa");
            return;
        }

        txtResult.setText("");
        btnSearch.setEnabled(false);
        lblStatus.setText("Đang tìm kiếm...");

        SwingWorker<Integer, String> worker = new SwingWorker<>() {
            @Override
            protected Integer doInBackground() throws Exception {
                int matchCount = 0;
                int lineNumber = 0;

                try (BufferedReader reader = Files.newBufferedReader(selectedFile.toPath(), StandardCharsets.UTF_8)) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        lineNumber++;
                        if (line.toLowerCase().contains(keyword)) {
                            matchCount++;
                            publish("Dòng " + lineNumber + ": " + line);
                        }
                    }
                }
                return matchCount;
            }

            @Override
            protected void process(List<String> chunks) {
                for (String text : chunks) {
                    txtResult.append(text + "\n");
                }
            }

            @Override
            protected void done() {
                try {
                    int total = get();
                    lblStatus.setText("Tìm thấy " + total + " dòng chứa từ khóa.");
                } catch (Exception ex) {
                    lblStatus.setText("Lỗi khi đọc file");
                }
                btnSearch.setEnabled(true);
            }
        };

        worker.execute();
    }
}