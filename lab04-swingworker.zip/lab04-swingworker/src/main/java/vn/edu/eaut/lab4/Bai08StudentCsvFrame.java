package vn.edu.eaut.lab4;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.BufferedReader;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Vector;

public class Bai08StudentCsvFrame extends JFrame {
    private JButton btnChoose;
    private JTable table;
    private DefaultTableModel tableModel;
    private JLabel lblStats;

    public Bai08StudentCsvFrame() {
        setTitle("Bài 8 - Đọc CSV và Thống kê điểm");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        btnChoose = new JButton("Chọn file CSV");
        lblStats = new JLabel("Thống kê: Chưa có dữ liệu", SwingConstants.CENTER);

        tableModel = new DefaultTableModel(new String[]{"Mã SV", "Họ Tên", "Điểm"}, 0);
        table = new JTable(tableModel);

        JPanel topPanel = new JPanel();
        topPanel.add(btnChoose);

        setLayout(new BorderLayout(10, 10));
        add(topPanel, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
        add(lblStats, BorderLayout.SOUTH);

        btnChoose.addActionListener(e -> loadCsv());
    }

    private void loadCsv() {
        JFileChooser chooser = new JFileChooser();
        if (chooser.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) return;

        File file = chooser.getSelectedFile();
        tableModel.setRowCount(0);
        lblStats.setText("Đang tải dữ liệu...");

        SwingWorker<String, Vector<Object>> worker = new SwingWorker<>() {
            @Override
            protected String doInBackground() throws Exception {
                double totalScore = 0;
                int count = 0;
                double maxScore = -1;
                String topStudent = "";

                try (BufferedReader reader = Files.newBufferedReader(file.toPath(), StandardCharsets.UTF_8)) {
                    String line;
                    boolean isHeader = true;
                    while ((line = reader.readLine()) != null) {
                        if (isHeader) { isHeader = false; continue; }

                        String[] parts = line.split(",");
                        if (parts.length >= 3) {
                            String maSV = parts[0].trim();
                            String hoTen = parts[1].trim();
                            double diem = Double.parseDouble(parts[2].trim());

                            Vector<Object> row = new Vector<>();
                            row.add(maSV); row.add(hoTen); row.add(diem);
                            publish(row);

                            totalScore += diem;
                            count++;
                            if (diem > maxScore) {
                                maxScore = diem;
                                topStudent = hoTen + " (" + diem + ")";
                            }
                        }
                    }
                }
                if (count == 0) return "File rỗng";
                double avg = totalScore / count;
                return String.format("ĐTB: %.2f | Thủ khoa: %s", avg, topStudent);
            }

            @Override
            protected void process(java.util.List<Vector<Object>> chunks) {
                for (Vector<Object> row : chunks) {
                    tableModel.addRow(row);
                }
            }

            @Override
            protected void done() {
                try {
                    lblStats.setText(get());
                } catch (Exception ex) {
                    lblStats.setText("Lỗi đọc file CSV");
                }
            }
        };

        worker.execute();
    }
}