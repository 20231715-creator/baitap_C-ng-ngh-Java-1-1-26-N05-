package vn.edu.eaut.lab4;

import javax.swing.*;
import java.awt.*;

public class App extends JFrame {

    public App() {
        setTitle("Lab 4 - SwingWorker & Event Handling");
        setSize(400, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(10, 1, 5, 5));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        addButton(panel, "Bài 1: Đồng hồ đếm ngược", () -> new Bai01CountdownFrame().setVisible(true));
        addButton(panel, "Bài 2: Tiến trình tải dữ liệu", () -> new Bai02ProgressDemoFrame().setVisible(true));
        addButton(panel, "Bài 3: Tính tổng số nguyên tố", () -> new Bai03PrimeSumFrame().setVisible(true));
        addButton(panel, "Bài 4: Số Fibonacci", () -> new Bai04FibonacciFrame().setVisible(true));
        addButton(panel, "Bài 5: Đọc file đếm dòng", () -> new Bai05FileLineCounterFrame().setVisible(true));
        addButton(panel, "Bài 6: Hủy tác vụ SwingWorker", () -> new Bai06CancelProgressFrame().setVisible(true));
        addButton(panel, "Bài 7: Tìm kiếm từ khóa file", () -> new Bai07FileSearchFrame().setVisible(true));
        addButton(panel, "Bài 8: Đọc CSV & Thống kê", () -> new Bai08StudentCsvFrame().setVisible(true));
        addButton(panel, "Bài 9: Tải danh sách sản phẩm", () -> new Bai09ProductLoaderFrame().setVisible(true));
        addButton(panel, "Bài 10: Quản lý sản phẩm CSV", () -> new Bai10ProductManagerFrame().setVisible(true));

        add(panel);
    }

    private void addButton(JPanel panel, String title, Runnable action) {
        JButton btn = new JButton(title);
        btn.addActionListener(e -> action.run());
        panel.add(btn);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new App().setVisible(true));
    }
}