package vn.edu.eaut.lab12.service;

import org.springframework.stereotype.Service;
import vn.edu.eaut.lab12.model.Student;
import java.util.ArrayList;
import java.util.List;

@Service
public class StudentService {
    private final List<Student> students = new ArrayList<>();
    private long nextId = 1;

    public StudentService() {
        save(new Student(null, "SV001", "Nguyễn Văn An", "an@gmail.com", "CNTT1"));
        save(new Student(null, "SV002", "Trần Thị Bình", "binh@gmail.com", "CNTT2"));
    }

    public List<Student> findAll() { return students; }

    public Student findById(Long id) {
        return students.stream().filter(s -> s.getId().equals(id)).findFirst().orElse(null);
    }

    public void save(Student student) {
        if (student.getId() == null) {
            student.setId(nextId++);
            students.add(student);
        } else {
            for (int i = 0; i < students.size(); i++) {
                if (students.get(i).getId().equals(student.getId())) {
                    students.set(i, student);
                    break;
                }
            }
        }
    }

    public void delete(Long id) {
        students.removeIf(s -> s.getId().equals(id));
    }

    public List<Student> searchByName(String keyword) {
        if (keyword == null || keyword.isBlank()) return findAll();
        return students.stream()
                .filter(s -> s.getFullName().toLowerCase().contains(keyword.toLowerCase()))
                .toList();
    }
    
    public boolean isStudentCodeExists(String code, Long id) {
        return students.stream().anyMatch(s -> s.getStudentCode().equals(code) && !s.getId().equals(id));
    }
}