package vn.edu.eaut.lab3;

import javax.swing.*;
import java.awt.*;

public class Bai07MayTinhMini extends JFrame {
    private final JTextField txtNum1 = new JTextField(10);
    private final JTextField txtNum2 = new JTextField(10);
    private final JTextField txtResult = new JTextField(15);
    private final JTextArea txtHistory = new JTextArea(8, 30);

    public Bai07MayTinhMini() {
        setTitle("Bài 7 - Máy tính Mini");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JPanel inputPanel = new JPanel(new GridLayout(3, 2, 5, 5));
        inputPanel.setBorder(BorderFactory.createTitledBorder("Nhập dữ liệu"));
        inputPanel.add(new JLabel("Số thứ nhất:"));
        inputPanel.add(txtNum1);
        inputPanel.add(new JLabel("Số thứ hai:"));
        inputPanel.add(txtNum2);
        inputPanel.add(new JLabel("Kết quả:"));

        txtResult.setEditable(false);
        txtResult.setFont(new Font("SansSerif", Font.BOLD, 12));
        inputPanel.add(txtResult);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 8));
        JButton btnAdd = new JButton("+");
        JButton btnSub = new JButton("-");
        JButton btnMul = new JButton("*");
        JButton btnDiv = new JButton("/");
        JButton btnClear = new JButton("Clear");

        btnPanel.add(btnAdd);
        btnPanel.add(btnSub);
        btnPanel.add(btnMul);
        btnPanel.add(btnDiv);
        btnPanel.add(btnClear);

        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.add(inputPanel, BorderLayout.CENTER);
        centerPanel.add(btnPanel, BorderLayout.SOUTH);

        txtHistory.setEditable(false);
        JScrollPane historyScrollPane = new JScrollPane(txtHistory);
        historyScrollPane.setBorder(BorderFactory.createTitledBorder("Lịch sử tính toán"));

        btnAdd.addActionListener(e -> xuLyPhepTinh("+"));
        btnSub.addActionListener(e -> xuLyPhepTinh("-"));
        btnMul.addActionListener(e -> xuLyPhepTinh("*"));
        btnDiv.addActionListener(e -> xuLyPhepTinh("/"));
        btnClear.addActionListener(e -> xoaForm());

        add(centerPanel, BorderLayout.NORTH);
        add(historyScrollPane, BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
    }

    private void xuLyPhepTinh(String operator) {
        try {
            double n1 = Double.parseDouble(txtNum1.getText().trim());
            double n2 = Double.parseDouble(txtNum2.getText().trim());
            double res = 0;
            String expression = "";

            switch (operator) {
                case "+" -> {
                    res = n1 + n2;
                    expression = String.format("%.2f + %.2f = %.2f\n", n1, n2, res);
                }
                case "-" -> {
                    res = n1 - n2;
                    expression = String.format("%.2f - %.2f = %.2f\n", n1, n2, res);
                }
                case "*" -> {
                    res = n1 * n2;
                    expression = String.format("%.2f * %.2f = %.2f\n", n1, n2, res);
                }
                case "/" -> {
                    if (Math.abs(n2) < 1e-9) {
                        JOptionPane.showMessageDialog(this, "Không thể chia cho 0!", "Lỗi toán học", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    res = n1 / n2;
                    expression = String.format("%.2f / %.2f = %.2f\n", n1, n2, res);
                }
            }

            txtResult.setText(String.format("%.2f", res));
            txtHistory.append(expression);

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập đúng định dạng số!", "Lỗi định dạng", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void xoaForm() {
        txtNum1.setText("");
        txtNum2.setText("");
        txtResult.setText("");
        txtNum1.requestFocus();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Bai07MayTinhMini().setVisible(true));
    }
}