package vn.edu.eaut.lab3;

public class Student {
    private String maSV;
    private String hoTen;
    private double dtb;

    public Student(String maSV, String hoTen, double dtb) {
        this.maSV = maSV;
        this.hoTen = hoTen;
        this.dtb = dtb;
    }

    public String getMaSV() { return maSV; }
    public void setMaSV(String maSV) { this.maSV = maSV; }

    public String getHoTen() { return hoTen; }
    public void setHoTen(String hoTen) { this.hoTen = hoTen; }

    public double getDtb() { return dtb; }
    public void setDtb(double dtb) { this.dtb = dtb; }

    public String xepLoai() {
        if (dtb >= 8.5) return "Giỏi";
        if (dtb >= 7.0) return "Khá";
        if (dtb >= 5.0) return "Trung bình";
        return "Yếu";
    }
}