package vn.edu.eaut.lab3;

import javax.swing.*;
import java.awt.*;

public class Bai06LoginForm extends JFrame {
    private final JTextField txtUsername = new JTextField(15);
    private final JPasswordField txtPassword = new JPasswordField(15);
    private final JComboBox<String> cbRole = new JComboBox<>(new String[]{"Admin", "User"});
    private final JCheckBox chkShowPassword = new JCheckBox("Hiển thị mật khẩu");

    public Bai06LoginForm() {
        setTitle("Bài 6 - Form Đăng nhập");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JPanel formPanel = new JPanel(new GridLayout(4, 2, 8, 8));
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        formPanel.add(new JLabel("Tài khoản:"));
        formPanel.add(txtUsername);

        formPanel.add(new JLabel("Mật khẩu:"));
        formPanel.add(txtPassword);

        formPanel.add(new JLabel("Vai trò:"));
        formPanel.add(cbRole);

        formPanel.add(new JLabel(""));
        formPanel.add(chkShowPassword);

        JButton btnLogin = new JButton("Đăng nhập");
        JPanel btnPanel = new JPanel();
        btnPanel.add(btnLogin);

        chkShowPassword.addActionListener(e -> {
            if (chkShowPassword.isSelected()) {
                txtPassword.setEchoChar((char) 0);
            } else {
                txtPassword.setEchoChar('•');
            }
        });

        btnLogin.addActionListener(e -> xuLyDangNhap());

        add(formPanel, BorderLayout.CENTER);
        add(btnPanel, BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(null);
    }

    private void xuLyDangNhap() {
        String username = txtUsername.getText().trim();
        String password = new String(txtPassword.getPassword());
        String role = (String) cbRole.getSelectedItem();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ tài khoản và mật khẩu!",
                    "Lỗi nhập liệu", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if ("Admin".equals(role) && "admin".equalsIgnoreCase(username) && "123456".equals(password)) {
            JOptionPane.showMessageDialog(this, "Đăng nhập thành công với quyền Admin!",
                    "Thành công", JOptionPane.INFORMATION_MESSAGE);
        } else if ("User".equals(role) && "user".equalsIgnoreCase(username) && "123456".equals(password)) {
            JOptionPane.showMessageDialog(this, "Đăng nhập thành công với quyền User!",
                    "Thành công", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Tài khoản, mật khẩu hoặc vai trò không chính xác!",
                    "Lỗi đăng nhập", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Bai06LoginForm().setVisible(true));
    }
}