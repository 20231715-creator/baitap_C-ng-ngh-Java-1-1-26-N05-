package vn.edu.eaut.lab3;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Bai08QuanLySinhVien extends JFrame {
    private final JTextField txtMaSV = new JTextField(15);
    private final JTextField txtHoTen = new JTextField(15);
    private final JTextField txtDTB = new JTextField(15);

    private final DefaultTableModel tableModel;
    private final JTable tblStudent;
    private final List<Student> studentList = new ArrayList<>();

    public Bai08QuanLySinhVien() {
        setTitle("Bài 8 - Quản Lý Sinh Viên");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JPanel inputPanel = new JPanel(new GridLayout(3, 2, 8, 8));
        inputPanel.setBorder(BorderFactory.createTitledBorder("Thông tin sinh viên"));
        inputPanel.add(new JLabel("Mã sinh viên:"));
        inputPanel.add(txtMaSV);
        inputPanel.add(new JLabel("Họ tên:"));
        inputPanel.add(txtHoTen);
        inputPanel.add(new JLabel("Điểm TB:"));
        inputPanel.add(txtDTB);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        JButton btnAdd = new JButton("Thêm");
        JButton btnEdit = new JButton("Sửa");
        JButton btnDelete = new JButton("Xóa");
        JButton btnClear = new JButton("Làm mới");

        btnPanel.add(btnAdd);
        btnPanel.add(btnEdit);
        btnPanel.add(btnDelete);
        btnPanel.add(btnClear);

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(inputPanel, BorderLayout.CENTER);
        topPanel.add(btnPanel, BorderLayout.SOUTH);

        String[] columnNames = {"Mã SV", "Họ và Tên", "Điểm TB", "Xếp Loại"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tblStudent = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(tblStudent);

        btnAdd.addActionListener(e -> themSinhVien());
        btnEdit.addActionListener(e -> suaSinhVien());
        btnDelete.addActionListener(e -> xoaSinhVien());
        btnClear.addActionListener(e -> lamMoiForm());

        tblStudent.getSelectionModel().addListSelectionListener(e -> hienThiDongDaChon());

        add(topPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
    }

    private void themSinhVien() {
        if (!kiemTraInput()) return;

        String ma = txtMaSV.getText().trim();
        for (Student s : studentList) {
            if (s.getMaSV().equalsIgnoreCase(ma)) {
                JOptionPane.showMessageDialog(this, "Mã sinh viên đã tồn tại!", "Lỗi trùng lặp", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        Student s = new Student(ma, txtHoTen.getText().trim(), Double.parseDouble(txtDTB.getText().trim()));
        studentList.add(s);
        capNhatTable();
        lamMoiForm();
    }

    private void suaSinhVien() {
        int selectedRow = tblStudent.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn dòng cần sửa!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (!kiemTraInput()) return;

        Student s = studentList.get(selectedRow);
        s.setHoTen(txtHoTen.getText().trim());
        s.setDtb(Double.parseDouble(txtDTB.getText().trim()));

        capNhatTable();
        lamMoiForm();
    }

    private void xoaSinhVien() {
        int selectedRow = tblStudent.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn dòng cần xóa!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "Bạn có chắc chắn muốn xóa sinh viên này?",
                "Xác nhận", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            studentList.remove(selectedRow);
            capNhatTable();
            lamMoiForm();
        }
    }

    private void hienThiDongDaChon() {
        int selectedRow = tblStudent.getSelectedRow();
        if (selectedRow != -1) {
            Student s = studentList.get(selectedRow);
            txtMaSV.setText(s.getMaSV());
            txtMaSV.setEditable(false);
            txtHoTen.setText(s.getHoTen());
            txtDTB.setText(String.valueOf(s.getDtb()));
        }
    }

    private void lamMoiForm() {
        txtMaSV.setText("");
        txtMaSV.setEditable(true);
        txtHoTen.setText("");
        txtDTB.setText("");
        tblStudent.clearSelection();
        txtMaSV.requestFocus();
    }

    private void capNhatTable() {
        tableModel.setRowCount(0);
        for (Student s : studentList) {
            tableModel.addRow(new Object[]{s.getMaSV(), s.getHoTen(), s.getDtb(), s.xepLoai()});
        }
    }

    private boolean kiemTraInput() {
        if (txtMaSV.getText().trim().isEmpty() || txtHoTen.getText().trim().isEmpty() || txtDTB.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng điền đầy đủ thông tin!", "Lỗi nhập liệu", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        try {
            double dtb = Double.parseDouble(txtDTB.getText().trim());
            if (dtb < 0 || dtb > 10) {
                JOptionPane.showMessageDialog(this, "Điểm trung bình phải nằm trong khoảng 0 - 10!", "Lỗi điểm số", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Điểm trung bình phải là một số hợp lệ!", "Lỗi định dạng", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Bai08QuanLySinhVien().setVisible(true));
    }
}