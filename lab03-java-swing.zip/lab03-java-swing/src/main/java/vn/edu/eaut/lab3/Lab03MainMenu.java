package vn.edu.eaut.lab3;

import javax.swing.*;
import java.awt.*;

public class Lab03MainMenu extends JFrame {

    public Lab03MainMenu() {
        setTitle("LAB 3 - LẬP TRÌNH JAVA SWING");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(15, 15));

        // Tiêu đề
        JLabel lblTitle = new JLabel("BẢNG MENU BÀI TẬP LAB 3", JLabel.CENTER);
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 18));
        lblTitle.setBorder(BorderFactory.createEmptyBorder(15, 0, 5, 0));
        add(lblTitle, BorderLayout.NORTH);

        // Grid chứa 8 nút tương ứng 8 bài
        JPanel gridPanel = new JPanel(new GridLayout(4, 2, 12, 12));
        gridPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));

        JButton btn1 = new JButton("Bài 1: Chào người dùng");
        JButton btn2 = new JButton("Bài 2: Tính tổng 2 số");
        JButton btn3 = new JButton("Bài 3: Giải PT bậc nhất");
        JButton btn4 = new JButton("Bài 4: Phân loại tam giác");
        JButton btn5 = new JButton("Bài 5: Dãy Fibonacci");
        JButton btn6 = new JButton("Bài 6: Form Đăng nhập");
        JButton btn7 = new JButton("Bài 7: Máy tính Mini");
        JButton btn8 = new JButton("Bài 8: Quản lý sinh viên");

        gridPanel.add(btn1);
        gridPanel.add(btn2);
        gridPanel.add(btn3);
        gridPanel.add(btn4);
        gridPanel.add(btn5);
        gridPanel.add(btn6);
        gridPanel.add(btn7);
        gridPanel.add(btn8);

        add(gridPanel, BorderLayout.CENTER);

        // Sự kiện mở bài tương ứng
        btn1.addActionListener(e -> openFrame(new Bai01HelloSwing()));
        btn2.addActionListener(e -> openFrame(new Bai02TongHaiSo()));
        btn3.addActionListener(e -> openFrame(new Bai03PhuongTrinhBacNhat()));
        btn4.addActionListener(e -> openFrame(new Bai04TamGiacSwing()));
        btn5.addActionListener(e -> openFrame(new Bai05FibonacciSwing()));
        btn6.addActionListener(e -> openFrame(new Bai06LoginForm()));
        btn7.addActionListener(e -> openFrame(new Bai07MayTinhMini()));
        btn8.addActionListener(e -> openFrame(new Bai08QuanLySinhVien()));

        pack();
        setLocationRelativeTo(null);
    }

    // Tự động chuyển chế độ để khi tắt giao diện bài con không làm thoát Menu chính
    private void openFrame(JFrame frame) {
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Lab03MainMenu().setVisible(true));
    }
}